local shoulddropweapon = true
local function shoulddropweapontoggle(ply)
	if(ply:IsAdmin()) then
		if (shoulddropweapon == true) then
			ply:PrintMessage(HUD_PRINTNOTIFY, "Weapon drop disabled") //Tell us if it is enabled.
			shoulddropweapon = false
		else //If it isn't, disable the variable.
			ply:PrintMessage(HUD_PRINTNOTIFY, "Weapon drop enabled")
			shoulddropweapon = true
		end
	end
end
local function dropweaponplayer(ply)
	if (shoulddropweapon == true and ply:GetActiveWeapon():IsValid()) then //If weapon dropping is enabled and the active weapon is valid then we continue
		ply:DropWeapon(ply:GetActiveWeapon()) //Get the main weapon and throw it.
	end
end
concommand.Add( "dropweapon", dropweaponplayer )
concommand.Add( "dropweapon_toggle", shoulddropweapontoggle )  
 hook.Add("DoPlayerDeath", "dropweaponondeath", dropweaponplayer)